import pygame
import math
import sys
import os

# Inicializar Pygame
pygame.init()
puntuacion_total = 0

# Dimensiones de pantalla
WIDTH, HEIGHT = 800, 600
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Aventura Numérica")

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 100, 200)
GRAY = (200, 200, 200)

# Fuentes
font_title = pygame.font.SysFont(None, 80)
font_button = pygame.font.SysFont(None, 40)
font_text = pygame.font.SysFont(None, 32)

# Botones
play_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 50, 200, 60)
exit_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 30, 200, 60)

# Carga de imágenes
# Cargar frames del fondo animado del menú
def cargar_frames_menu(ruta_carpeta, tamaño):
    frames = []
    for nombre in sorted(os.listdir(ruta_carpeta)):
        if nombre.endswith(".png"):
            img = pygame.image.load(os.path.join(ruta_carpeta, nombre)).convert()
            img = pygame.transform.scale(img, tamaño)
            frames.append(img)
    return frames

# Carga los frames del menú animado
menu_frames = cargar_frames_menu("menu", (WIDTH, HEIGHT))
frame_menu_actual = 0
contador_menu_frames = 0
retardo_menu_animacion = 5  # Ajusta velocidad de animación

# carga los frames de los niveles
def cargar_frames_desde_carpeta(ruta_carpeta):
    frames = []
    for nombre in sorted(os.listdir(ruta_carpeta)):
        if nombre.endswith((".png", ".jpg", ".gif")):
            imagen = pygame.image.load(os.path.join(ruta_carpeta, nombre)).convert_alpha()
            imagen = pygame.transform.scale(imagen, (100, 100))  # Asegúrate del tamaño
            frames.append(imagen)
    return frames

# Animaciones para éxito
cientifico_frames = cargar_frames_desde_carpeta("cientifico_moviendose" )
puerta_frames = cargar_frames_desde_carpeta("puerta_abriendose")


#carga de imagenes de imagenes usadas
cientifico = pygame.image.load("cientifico.gif")
puerta_cerrada = pygame.image.load("puerta.gif")
fondo = pygame.image.load("laboratorio.gif")
fondo_nivel2 = pygame.image.load("nivel2.gif")
fondo_nivel3 =  pygame.image.load("fondo_nivel3.gif")
fondo_nivel4 = pygame.image.load("fondo_nivel4.gif")
fondo_nivel5 = pygame.image.load("fondo_nivel5.jpg")
fondo_nivel7 = pygame.image.load("fondo_nivel7.jpg")

# Escalamos las imagenes
fondo = pygame.transform.scale(fondo, (SCREEN_WIDTH, SCREEN_HEIGHT))
fondo_nivel2 = pygame.transform.scale(fondo_nivel2, (SCREEN_WIDTH, SCREEN_HEIGHT))
fondo_nivel3 = pygame.transform.scale(fondo_nivel3, (SCREEN_WIDTH, SCREEN_HEIGHT))
fondo_nivel4 = pygame.transform.scale(fondo_nivel4, (SCREEN_WIDTH, SCREEN_HEIGHT))
fondo_nivel5 = pygame.transform.scale(fondo_nivel5, (SCREEN_WIDTH, SCREEN_HEIGHT))
fondo_nivel7 = pygame.transform.scale(fondo_nivel7, (SCREEN_WIDTH, SCREEN_HEIGHT))
cientifico = pygame.transform.scale(cientifico, (100, 100))
puerta_cerrada = pygame.transform.scale(puerta_cerrada, (100, 100))

def dibujar_texto_en_caja(texto, fuente, color_texto, x, y, padding=10):
    render = fuente.render(texto, True, color_texto)
    ancho, alto = render.get_size()
    caja_rect = pygame.Rect(x - padding, y - padding, ancho + 2 * padding, alto + 2 * padding)
    pygame.draw.rect(screen, WHITE, caja_rect)         # Fondo blanco
    pygame.draw.rect(screen, BLACK, caja_rect, 2)      # Borde negro
    screen.blit(render, (x, y))

def dibujar_textos_en_caja_grande(lista_textos, fuente, color_texto, y, padding=10, espaciado=5):
    # Preparar los textos
    lineas_render = [fuente.render(texto, True, color_texto) for texto in lista_textos]
    alto_total = sum(r.get_height() + espaciado for r in lineas_render) - espaciado
    caja_altura = alto_total + 2 * padding
    caja_rect = pygame.Rect(0, y - padding, SCREEN_WIDTH, caja_altura)

    # Crear una superficie semitransparente
    fondo_caja = pygame.Surface((SCREEN_WIDTH, caja_altura), pygame.SRCALPHA)
    fondo_caja.fill((255, 255, 255, 180))  # Blanco con alfa (180 de 255)

    # Dibujar fondo y borde
    screen.blit(fondo_caja, (0, y - padding))
    pygame.draw.rect(screen, BLACK, caja_rect, 2)

    # Posicionar textos centrados
    y_actual = y
    for render in lineas_render:
        x = (SCREEN_WIDTH - render.get_width()) // 2
        screen.blit(render, (x, y_actual))
        y_actual += render.get_height() + espaciado
def dibujar_textos_en_caja_pie(lista_textos, fuente, color_texto, padding=10, espaciado=5):
    # Preparar los textos
    lineas_render = [fuente.render(texto, True, color_texto) for texto in lista_textos]
    alto_total = sum(r.get_height() + espaciado for r in lineas_render) - espaciado
    caja_altura = alto_total + 2 * padding
    y = SCREEN_HEIGHT - caja_altura  # Colocar al pie de la ventana

    caja_rect = pygame.Rect(0, y, SCREEN_WIDTH, caja_altura)

    # Crear superficie semitransparente
    fondo_caja = pygame.Surface((SCREEN_WIDTH, caja_altura), pygame.SRCALPHA)
    fondo_caja.fill((255, 255, 255, 180))  # Blanco con transparencia

    # Dibujar fondo y borde
    screen.blit(fondo_caja, (0, y))
    pygame.draw.rect(screen, BLACK, caja_rect, 2)

    # Dibujar texto alineado a la izquierda
    y_actual = y + padding
    for render in lineas_render:
        screen.blit(render, (padding, y_actual))
        y_actual += render.get_height() + espaciado

def mostrar_mensaje_centrado_doble_linea(texto1, texto2, fuente, color1, color2):
    render1 = fuente.render(texto1, True, color1)
    render2 = fuente.render(texto2, True, color2)

    ancho_caja = max(render1.get_width(), render2.get_width()) + 40
    alto_caja = render1.get_height() + render2.get_height() + 40
    x_caja = (WIDTH - ancho_caja) // 2
    y_caja = (HEIGHT - alto_caja) // 2

    fondo = pygame.Surface((ancho_caja, alto_caja))
    fondo.fill(WHITE)
    pygame.draw.rect(fondo, BLACK, fondo.get_rect(), 2)

    fondo.blit(render1, ((ancho_caja - render1.get_width()) // 2, 10))
    fondo.blit(render2, ((ancho_caja - render2.get_width()) // 2, 20 + render1.get_height()))

    screen.blit(fondo, (x_caja, y_caja))


# ----------------- NIVEL 1 -------------------
def nivel_1():
    global puntuacion_total
    #movimiento de cientifico y puerta
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0
    
    running = True
    input_text = ""
    resultado_correcto = 15.885
    tolerancia = 0.01
    tiempo_total = 600  # segundos
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)
        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo, (0, 0))

        # Científico y Puerta
        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:  # Cambiar de frame cada 5 ticks (~12 FPS)
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (600, 400))
            screen.blit(puerta_frames[frame_puerta], (600, 300))
        else:
            screen.blit(cientifico, (70, 200))
            screen.blit(puerta_cerrada, (600, 300))


        # Enunciado
        dibujar_texto_en_caja("Nivel 1 - Método de Lagrange", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion_total}", font_text, BLACK, 600, 30)
        dibujar_texto_en_caja("Tu respuesta: " + input_text, font_text, BLACK, 50, 395)
        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Para abrir la puerta necesito saber el código el cual se obtiene",
            "de calcular g(x) para x = 4.8",
            "xi = 5.9, 6.7, 6.3",
            "yi = -0.34, -1.12, -1.89",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)


        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Avanzas al siguiente nivel.",
                    "Presiona ENTER para continuar.",
                    font_text,
                    (0, 150, 0),  # Verde para texto1
                    (0, 150, 0)   # Verde también para la instrucción
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),  # Rojo para texto1
                    (200, 0, 0)   # Rojo también para la instrucción
                )


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            respuesta = float(input_text)
                            if abs(respuesta - resultado_correcto) <= tolerancia and tiempo_restante > 0:
                                puntos_obtenidos = int((tiempo_restante * 1) / 10)
                                puntuacion_total += puntos_obtenidos
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        nivel_2()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_1()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)
        

# ----------------- NIVEL 2 -------------------
def nivel_2():
    global puntuacion_total
    #movimiento de cientifico y puerta
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0
    
    running = True
    input_text = ""
    resultado1 = 1.127777778
    resultado2 = 0.9
    tolerancia = 0.0001
    tiempo_total = 600  # segundos
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)
        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo_nivel2, (0, 0))

        # Científico y Puerta
        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:  # Cambiar de frame cada 5 ticks (~12 FPS)
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (590, 300))
            screen.blit(puerta_frames[frame_puerta], (640, 200))
        else:
            screen.blit(cientifico, (115, 185))
            screen.blit(puerta_cerrada, (640, 200))


        # Enunciado
        dibujar_texto_en_caja("Nivel 2 - Newton hacia adelante", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion_total}", font_text, BLACK, 600, 30)
        dibujar_texto_en_caja("Tu respuesta: " + input_text, font_text, BLACK, 50, 380)
        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Necesito obtener g(x) para x = 8 y saber si los intervalos son uniformes",
            "para saber donde pisar. Ingresar g(x) y la diferencia entre los intervalos",
            "en el formato: N.N, N.N",
            "xi = 6.5, 7.4, 8.3",
            "yi = 0.80, 1.03, 1.16",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)


        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Avanzas al siguiente nivel.",
                    "Presiona ENTER para continuar.",
                    font_text,
                    (0, 150, 0),  # Verde para texto1
                    (0, 150, 0)   # Verde también para la instrucción
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),  # Rojo para texto1
                    (200, 0, 0)   # Rojo también para la instrucción
                )


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            partes = input_text.replace(",", " ").split()
                            if len(partes) != 2:
                                raise ValueError("Se esperaban dos valores.")
                            val1 = float(partes[0])
                            val2 = float(partes[1])

                            correcto1 = abs(val1 - resultado1) <= tolerancia
                            correcto2 = abs(val2 - resultado2) <= tolerancia

                            if correcto1 and correcto2 and tiempo_restante > 0:
                                puntos = int((tiempo_restante * 1) / 10)
                                puntuacion_total += puntos
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        nivel_3()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_2()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)
      
      
# ----------------- NIVEL 3 -------------------

def nivel_3():
    global puntuacion_total
    #movimiento de cientifico y puerta
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0
    
    running = True
    input_text = ""
    resultado1 = -1.061428573
    resultado2 = -0.047619047
    tolerancia = 0.0001
    tiempo_total = 600  # segundos
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)
        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo_nivel3, (0, 0))

        # Científico y Puerta
        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:  # Cambiar de frame cada 5 ticks (~12 FPS)
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (415, 100))
            screen.blit(puerta_frames[frame_puerta], (415, 0))
        else:
            screen.blit(cientifico, (80, 220))
            screen.blit(puerta_cerrada, (415, 0))


        # Enunciado
        dibujar_texto_en_caja("Nivel 3 - Newton con diferencias divididas", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion_total}", font_text, BLACK, 600, 30)
        dibujar_texto_en_caja("Tu respuesta: " + input_text, font_text, BLACK, 50, 350)
        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Necesito obtener g(x) para x = 5 y conocer el valor de D²1",
            "para saber a cuanta distancia debo abrir la puerta.",
            "Ingresa g(x) y el valor de D²1",
            "en el formato: N.N, N.N",
            "xi = 6.8, 4.2, 3.5",
            "yi = -0.95, -1.21, -1.39",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)


        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Avanzas al siguiente nivel.",
                    "Presiona ENTER para continuar.",
                    font_text,
                    (0, 150, 0),  # Verde para texto1
                    (0, 150, 0)   # Verde también para la instrucción
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),  # Rojo para texto1
                    (200, 0, 0)   # Rojo también para la instrucción
                )


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            partes = input_text.replace(",", " ").split()
                            if len(partes) != 2:
                                raise ValueError("Se esperaban dos valores.")
                            val1 = float(partes[0])
                            val2 = float(partes[1])

                            correcto1 = abs(val1 - resultado1) <= tolerancia
                            correcto2 = abs(val2 - resultado2) <= tolerancia

                            if correcto1 and correcto2 and tiempo_restante > 0:
                                puntos = int((tiempo_restante * 1) / 10)
                                puntuacion_total += puntos
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        print("avanzando al nivel 4")#nivel_4()
                        nivel_4() #avanza al siguiente nivel
                    elif event.key == pygame.K_ESCAPE:
                        nivel_3()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)      
      
# ----------------- NIVEL 4 -------------------
def nivel_4():
    global puntuacion_total
    #movimiento de cientifico y puerta
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0
    
    running = True
    input_text = ""
    resultado1 = 0.483609467
    resultado2 = 0.076923067
    tolerancia = 0.0001
    tiempo_total = 600  # segundos
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)
        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo_nivel4, (0, 0))

        # Científico y Puerta
        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:  # Cambiar de frame cada 5 ticks (~12 FPS)
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (300, 30))
            screen.blit(puerta_frames[frame_puerta], (400, 0))
        else:
            screen.blit(cientifico, (300, 240))
            screen.blit(puerta_cerrada, (400, 0))


        # Enunciado
        dibujar_texto_en_caja("Nivel 4 - Newton hacia atras", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion_total}", font_text, BLACK, 600, 30)
        dibujar_texto_en_caja("Tu respuesta: " + input_text, font_text, BLACK, 50, 380)
        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Necesito obtener g(x) para x = 3 y conocer el valor de s",
            "para saber cuantas escaleras subir. Ingresar g(x) y el valor de s",
            "en el formato: N.N, N.N",
            "xi = 0.5, 1.8, 3.1",
            "yi = 0.11, 0.25, 0.47",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)


        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Avanzas al siguiente nivel.",
                    "Presiona ENTER para continuar.",
                    font_text,
                    (0, 150, 0),  # Verde para texto1
                    (0, 150, 0)   # Verde también para la instrucción
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),  # Rojo para texto1
                    (200, 0, 0)   # Rojo también para la instrucción
                )


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            partes = input_text.replace(",", " ").split()
                            if len(partes) != 2:
                                raise ValueError("Se esperaban dos valores.")
                            val1 = float(partes[0])
                            val2 = float(partes[1])

                            correcto1 = abs(val1 - resultado1) <= tolerancia
                            correcto2 = abs(val2 - resultado2) <= tolerancia

                            if correcto1 and correcto2 and tiempo_restante > 0:
                                puntos = int((tiempo_restante * 1) / 10)
                                puntuacion_total += puntos
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        nivel_5()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_4()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)
        
# ----------------- NIVEL 5 -------------------
def nivel_5():
    global puntuacion_total
    # Movimiento de científico y puerta
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0
    
    running = True
    input_text = ""
    resultado1 = 10.0  # g(x) en x=3
    resultado2 = 0.0   # ε
    tolerancia = 0.0001
    tiempo_total = 300  # 5 minutos
    mostrar_resultado = False
    exito = False
    razon_error = ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)
        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo_nivel5, (0, 0))

        # Científico y Puerta
        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (30, 110))
            screen.blit(puerta_frames[frame_puerta], (135, 60))
        else:
            screen.blit(cientifico, (400, 250))
            screen.blit(puerta_cerrada, (135, 60))

        # Enunciado
        dibujar_texto_en_caja("Nivel 5 - Interpolación Lineal", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion_total}", font_text, BLACK, 600, 30)
        dibujar_texto_en_caja("Tu respuesta: " + input_text, font_text, BLACK, 50, 380)
        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Los valores de xi = 2, 4 y yi = 4, 16 se conocen.",
            "Necesito saber el valor de g(x) en x = 3 y el error ε",
            "si el valor real en x=3 es 10.",
            "Ingresa las respuestas como: N.NN, N.NN",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)

        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Avanzas al siguiente nivel.",
                    "Presiona ENTER para continuar.",
                    font_text,
                    (0, 150, 0),
                    (0, 150, 0)
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),
                    (200, 0, 0)
                )

        # Eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            partes = input_text.replace(",", " ").split()
                            if len(partes) != 2:
                                raise ValueError("Se esperaban dos valores.")
                            val1 = float(partes[0])
                            val2 = float(partes[1])

                            correcto1 = abs(val1 - resultado1) <= tolerancia
                            correcto2 = abs(val2 - resultado2) <= tolerancia

                            if correcto1 and correcto2 and tiempo_restante > 0:
                                puntos = int((tiempo_restante * 1) / 10)
                                puntuacion_total += puntos
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito: 
                        nivel_6()# llama nuevo nivel
                    elif event.key == pygame.K_ESCAPE:
                        nivel_5()  # Reinicia el nivel
                        return

        # Si el tiempo se agota
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)        
        
# ----------------- NIVEL 7 -------------------
def nivel_6():
    global puntuacion_total
    #movimiento de cientifico y puerta
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0
    
    running = True
    input_text = ""
    input_text_1 = ""
    input_text_2= ""
    caja_activa = 1
    resultado_correcto_1 = 9
    resultado_correcto_2 = 0.001946875
    tolerancia = 0.0001
    tiempo_total = 600  # segundos
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)
        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo_nivel7, (0, 0))

        # Científico y Puerta
        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:  # Cambiar de frame cada 5 ticks (~12 FPS)
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (400, 350))
            screen.blit(puerta_frames[frame_puerta], (500, 310))
        else:
            screen.blit(cientifico, (70, 100))
            screen.blit(puerta_cerrada, (500, 310))


        # Enunciado
        dibujar_texto_en_caja("Nivel 6 - Método de la bisectriz", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion_total}", font_text, BLACK, 600, 30)

        #Respuestas en Horizontal
        dibujar_texto_en_caja("Tus respuestas: " + input_text, font_text, BLACK, 50, 350)
        dibujar_texto_en_caja("Iteraciones: " + input_text_1, font_text, BLACK, 50, 400)
        dibujar_texto_en_caja("εx: " + input_text_2, font_text, BLACK, 550, 400)

        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Para abrir la siguiente puerta necesito introducir dos códigos" , 
            "los cuales se obtienen mediante",
            "calcular y= x²-2.2x-4 por el método de la bisectriz",
            "Usa la tecla TAB para cambiar entre las cajas de texto",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)


        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Avanzas al siguiente nivel.",
                    "Presiona ENTER para continuar.",
                    font_text,
                    (0, 150, 0),  # Verde para texto1
                    (0, 150, 0)   # Verde también para la instrucción
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),  # Rojo para texto1
                    (200, 0, 0)   # Rojo también para la instrucción
                )


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        # Eliminar el último carácter de la caja activa
                        if caja_activa == 1:
                            input_text_1 = input_text_1[:-1]
                        elif caja_activa == 2:
                            input_text_2 = input_text_2[:-1]
                    elif event.key == pygame.K_TAB:
                        # Cambiar la caja activa (1 -> 2 -> 3 -> 1)
                        caja_activa = (caja_activa % 3) + 1
                    elif event.key == pygame.K_RETURN:
                        try:
                            respuesta_1 = float(input_text_1)
                            respuesta_2 = float(input_text_2)
                            if (
                                abs(respuesta_1 - resultado_correcto_1) <= tolerancia and
                                abs(respuesta_2 - resultado_correcto_2) <= tolerancia and
                                tiempo_restante > 0
                            ):
                                puntos_obtenidos = int((tiempo_restante * 1) / 10)
                                puntuacion_total += puntos_obtenidos
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text_1 = ""
                        input_text_2 = ""
                    else:
                        # Agregar texto a la caja activa
                        if caja_activa == 1:
                            input_text_1 += event.unicode
                        elif caja_activa == 2:
                            input_text_2 += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        nivel_7()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_6()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)

# ----------------- NIVEL 7 -------------------
def nivel_7():
    global puntuacion_total #movimiento de cientifico y puerta
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0

    running = True
    input_text_1 = ""  # Primera caja de texto
    input_text_2 = ""  # Segunda caja de texto
    input_text_3 = ""  # Tercera caja de texto
    caja_activa = 1  # Indica cuál caja está activa (1, 2 o 3)
    resultado_correcto_1 = 5  # Respuesta correcta para la primera caja
    resultado_correcto_2 = 0.794580494 # Respuesta correcta para la segunda caja
    resultado_correcto_3 = 0  # Respuesta correcta para la tercera caja
    tolerancia = 0.05
    tiempo_total = 600  # segundos
    puntuacion = 0
    mostrar_resultado = False
    exito = False
    razon_error = ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)

        screen.fill(WHITE)

        # Fondo
        screen.blit(fondo_nivel3, (0, 0))

        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:  # Cambiar de frame cada 5 ticks (~12 FPS)
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (600, 400))
            screen.blit(puerta_frames[frame_puerta], (600, 300))
        else:
            screen.blit(cientifico, (70, 200))
            screen.blit(puerta_cerrada, (600, 300))

        # Enunciado
        dibujar_texto_en_caja("Nivel 7 - Método de Newton-Raphson", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion}", font_text, BLACK, 600, 30)

        # Respuestas en horizontal
        dibujar_texto_en_caja("Iteraciones: " + input_text_1, font_text, BLACK, 50, 370)
        dibujar_texto_en_caja("Respuesta: " + input_text_2, font_text, BLACK, 290, 370)
        dibujar_texto_en_caja("ε: " + input_text_3, font_text, BLACK, 600, 370)

        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Para continuar necesito resolver el siguiente problema para obtener el",
            "código:",
            "Encuentre la raíz real de la siguiente ecuación:",
            "x^3 - 4x^2 + 5x - 7",
            "Usa la tecla TAB para cambiar entre las cajas de texto.",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)

        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Has completado el juego.",
                    "Presiona ENTER para salir.",
                    font_text,
                    (0, 150, 0),
                    (0, 150, 0)
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),
                    (200, 0, 0)
                )

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        # Eliminar el último carácter de la caja activa
                        if caja_activa == 1:
                            input_text_1 = input_text_1[:-1]
                        elif caja_activa == 2:
                            input_text_2 = input_text_2[:-1]
                        elif caja_activa == 3:
                            input_text_3 = input_text_3[:-1]
                    elif event.key == pygame.K_TAB:
                        # Cambiar la caja activa (1 -> 2 -> 3 -> 1)
                        caja_activa = (caja_activa % 3) + 1
                    elif event.key == pygame.K_RETURN:
                        try:
                            respuesta_1 = float(input_text_1)
                            respuesta_2 = float(input_text_2)
                            respuesta_3 = float(input_text_3)
                            # Evaluar las respuestas
                            if (
                                abs(respuesta_1 - resultado_correcto_1) <= tolerancia and
                                abs(respuesta_2 - resultado_correcto_2) <= tolerancia and
                                abs(respuesta_3 - resultado_correcto_3) <= tolerancia and
                                tiempo_restante > 0
                            ):
                                puntuacion = int(tiempo_restante * 10)
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text_1 = ""
                        input_text_2 = ""
                        input_text_3 = ""
                    else:
                        # Agregar texto a la caja activa
                        if caja_activa == 1:
                            input_text_1 += event.unicode
                        elif caja_activa == 2:
                            input_text_2 += event.unicode
                        elif caja_activa == 3:
                            input_text_3 += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        main_menu()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_7()  # Reinicia el nivel
                        return

        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)

# ----------------- MENÚ PRINCIPAL -------------------
def draw_menu():
    global frame_menu_actual, contador_menu_frames

    # Animar fondo del menú
    contador_menu_frames += 1
    if contador_menu_frames >= retardo_menu_animacion:
        frame_menu_actual = (frame_menu_actual + 1) % len(menu_frames)
        contador_menu_frames = 0

    screen.blit(menu_frames[frame_menu_actual], (0, 0))


    # Título con borde blanco
    title_text = font_title.render("Aventura Numérica", True, BLUE)
    outline = font_title.render("Aventura Numérica", True, WHITE)
    x = WIDTH // 2 - title_text.get_width() // 2
    y = 100
    screen.blit(outline, (x - 2, y))
    screen.blit(outline, (x + 2, y))
    screen.blit(outline, (x, y - 2))
    screen.blit(outline, (x, y + 2))
    screen.blit(title_text, (x, y))
    
    # Subtítulo "Equipo 7"
    team_text = font_button.render("Equipo 7", True, WHITE)
    team_x = WIDTH // 2 - team_text.get_width() // 2
    team_y = y + title_text.get_height() + 10  # Debajo del título con un margen
    screen.blit(team_text, (team_x, team_y))

    # Obtener posición del mouse
    mouse_pos = pygame.mouse.get_pos()

    # Colores de botones
    play_color = (170, 170, 170) if play_button.collidepoint(mouse_pos) else GRAY
    exit_color = (170, 170, 170) if exit_button.collidepoint(mouse_pos) else GRAY

    # Botón Jugar
    pygame.draw.rect(screen, play_color, play_button)
    play_text = font_button.render("Jugar", True, BLACK)
    screen.blit(play_text, (play_button.centerx - play_text.get_width() // 2,
                            play_button.centery - play_text.get_height() // 2))

    # Botón Salir
    pygame.draw.rect(screen, exit_color, exit_button)
    exit_text = font_button.render("Salir", True, BLACK)
    screen.blit(exit_text, (exit_button.centerx - exit_text.get_width() // 2,
                             exit_button.centery - exit_text.get_height() // 2))

    pygame.display.flip()


def main_menu():
    while True:
        draw_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(event.pos):
                    nivel_1()  # Iniciar nivel
                elif exit_button.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()

# Ejecutar el menú
main_menu()
