import pygame
import sys

# Inicializar Pygame
pygame.init()

# Dimensiones de pantalla
WIDTH, HEIGHT = 800, 600
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Aventura Numérica")

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 100, 200)
GRAY = (200, 200, 200)

# Fuentes
font_title = pygame.font.SysFont(None, 80)
font_button = pygame.font.SysFont(None, 40)
font_text = pygame.font.SysFont(None, 32)

# Botones
play_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 50, 200, 60)
exit_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 30, 200, 60)

# Carga de imágenes
fondo = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/laboratorio.gif")
cientifico = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/cientifico.gif")
puerta_cerrada = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/puerta.gif")
puerta_abierta = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/puerta.gif")

# Escalamos si es necesario
fondo = pygame.transform.scale(fondo, (SCREEN_WIDTH, SCREEN_HEIGHT))
cientifico = pygame.transform.scale(cientifico, (100, 100))
puerta_cerrada = pygame.transform.scale(puerta_cerrada, (100, 100))
puerta_abierta = pygame.transform.scale(puerta_abierta, (100, 100))


# ----------------- NIVEL 1 -------------------
def nivel_1():
    running = True
    input_text = ""
    resultado_correcto = -1.4978125
    tolerancia = 0.05
    tiempo_total = 600  # segundos
    puntuacion = 0
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)

        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo, (0, 0))

        # Científico
        screen.blit(cientifico, (100, 300))

        # Puerta (depende del resultado)
        if mostrar_resultado and exito:
            screen.blit(puerta_abierta, (600, 300))
        else:
            screen.blit(puerta_cerrada, (600, 300))


        # Enunciado
        enunciado = font_button.render("Nivel 1 - Método de Lagrange", True, BLACK)
        screen.blit(enunciado, (50, 30))

        pregunta = font_text.render("Obten g(x) para x = 6.4", True, BLACK)
        screen.blit(pregunta, (50, 80))
        
        pregunta = font_text.render("xi = 7.3, 6.5, 6.1", True, BLACK)
        screen.blit(pregunta, (50, 130))
        
        pregunta = font_text.render("yi = -0.28, -1.35, -1.96", True, BLACK)
        screen.blit(pregunta, (50, 150))

        # Entrada
        input_render = font_text.render("Tu respuesta: " + input_text, True, BLUE)
        screen.blit(input_render, (50, 200))

        # Temporizador
        timer_render = font_text.render(f"Tiempo restante: {tiempo_restante}s", True, BLACK)
        screen.blit(timer_render, (50, 250))

        # Puntuación
        score_render = font_text.render(f"Puntuación: {puntuacion}", True, BLACK)
        screen.blit(score_render, (50, 280))

        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                msg = "¡Correcto! Avanzas al siguiente nivel."
                msg_render = font_text.render(msg, True, (0, 150, 0))
                screen.blit(msg_render, (50, 300))
                next_render = font_text.render("Presiona ENTER para continuar.", True, BLACK)
                screen.blit(next_render, (50, 340))
            else:
                if razon_error == "tiempo":
                    msg = "Se agotó el tiempo. Presiona ESC para volverlo a intentar."
                elif razon_error == "incorrecto":
                    msg = "Respuesta incorrecta. Presiona ESC para volverlo a intentar."
                else:
                    msg = "Presiona ESC para volverlo a intentar."

                msg_render = font_text.render(msg, True, (200, 0, 0))
                screen.blit(msg_render, (50, 300))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            respuesta = float(input_text)
                            if abs(respuesta - resultado_correcto) <= tolerancia and tiempo_restante > 0:
                                puntuacion = int(tiempo_restante * 10)
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        print("Avanzando al Nivel 2...")
                        running = False  # o nivel_2()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_1()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)

# ----------------- MENÚ PRINCIPAL -------------------
def draw_menu():
    screen.fill(WHITE)
    
    # Título
    title_text = font_title.render("Aventura Numérica", True, BLUE)
    screen.blit(title_text, (WIDTH//2 - title_text.get_width()//2, 100))

    # Botón Jugar
    pygame.draw.rect(screen, GRAY, play_button)
    play_text = font_button.render("Jugar", True, BLACK)
    screen.blit(play_text, (play_button.centerx - play_text.get_width()//2,
                            play_button.centery - play_text.get_height()//2))

    # Botón Salir
    pygame.draw.rect(screen, GRAY, exit_button)
    exit_text = font_button.render("Salir", True, BLACK)
    screen.blit(exit_text, (exit_button.centerx - exit_text.get_width()//2,
                             exit_button.centery - exit_text.get_height()//2))

    pygame.display.flip()

def main_menu():
    while True:
        draw_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(event.pos):
                    nivel_1()  # Iniciar nivel
                elif exit_button.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()

# Ejecutar el menú
main_menu()
