import pygame
import sys

# Inicializar Pygame
pygame.init()

# Dimensiones de pantalla
WIDTH, HEIGHT = 800, 600
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Aventura Numérica")

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 100, 200)
GRAY = (200, 200, 200)

# Fuentes
font_title = pygame.font.SysFont(None, 80)
font_button = pygame.font.SysFont(None, 40)
font_text = pygame.font.SysFont(None, 32)

# Botones
play_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 50, 200, 60)
exit_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 30, 200, 60)

# Carga de imágenes
fondo_menu = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/lab_menu.gif")
fondo_menu = pygame.transform.scale(fondo_menu, (SCREEN_WIDTH, SCREEN_HEIGHT))

fondo = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/laboratorio.gif")
cientifico = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/cientifico.gif")
puerta_cerrada = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/puerta.gif")
puerta_abierta = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/puerta.gif")

# Escalamos si es necesario
fondo = pygame.transform.scale(fondo, (SCREEN_WIDTH, SCREEN_HEIGHT))
cientifico = pygame.transform.scale(cientifico, (100, 100))
puerta_cerrada = pygame.transform.scale(puerta_cerrada, (100, 100))
puerta_abierta = pygame.transform.scale(puerta_abierta, (100, 100))

def dibujar_texto_en_caja(texto, fuente, color_texto, x, y, padding=10):
    render = fuente.render(texto, True, color_texto)
    ancho, alto = render.get_size()
    caja_rect = pygame.Rect(x - padding, y - padding, ancho + 2 * padding, alto + 2 * padding)
    pygame.draw.rect(screen, WHITE, caja_rect)         # Fondo blanco
    pygame.draw.rect(screen, BLACK, caja_rect, 2)      # Borde negro
    screen.blit(render, (x, y))

def dibujar_textos_en_caja_grande(lista_textos, fuente, color_texto, y, padding=10, espaciado=5):
    # Preparar los textos
    lineas_render = [fuente.render(texto, True, color_texto) for texto in lista_textos]
    alto_total = sum(r.get_height() + espaciado for r in lineas_render) - espaciado
    caja_altura = alto_total + 2 * padding
    caja_rect = pygame.Rect(0, y - padding, SCREEN_WIDTH, caja_altura)

    # Crear una superficie semitransparente
    fondo_caja = pygame.Surface((SCREEN_WIDTH, caja_altura), pygame.SRCALPHA)
    fondo_caja.fill((255, 255, 255, 180))  # Blanco con alfa (180 de 255)

    # Dibujar fondo y borde
    screen.blit(fondo_caja, (0, y - padding))
    pygame.draw.rect(screen, BLACK, caja_rect, 2)

    # Posicionar textos centrados
    y_actual = y
    for render in lineas_render:
        x = (SCREEN_WIDTH - render.get_width()) // 2
        screen.blit(render, (x, y_actual))
        y_actual += render.get_height() + espaciado
def dibujar_textos_en_caja_pie(lista_textos, fuente, color_texto, padding=10, espaciado=5):
    # Preparar los textos
    lineas_render = [fuente.render(texto, True, color_texto) for texto in lista_textos]
    alto_total = sum(r.get_height() + espaciado for r in lineas_render) - espaciado
    caja_altura = alto_total + 2 * padding
    y = SCREEN_HEIGHT - caja_altura  # Colocar al pie de la ventana

    caja_rect = pygame.Rect(0, y, SCREEN_WIDTH, caja_altura)

    # Crear superficie semitransparente
    fondo_caja = pygame.Surface((SCREEN_WIDTH, caja_altura), pygame.SRCALPHA)
    fondo_caja.fill((255, 255, 255, 180))  # Blanco con transparencia

    # Dibujar fondo y borde
    screen.blit(fondo_caja, (0, y))
    pygame.draw.rect(screen, BLACK, caja_rect, 2)

    # Dibujar texto alineado a la izquierda
    y_actual = y + padding
    for render in lineas_render:
        screen.blit(render, (padding, y_actual))
        y_actual += render.get_height() + espaciado



# ----------------- NIVEL 1 -------------------
def nivel_1():
    running = True
    input_text = ""
    resultado_correcto = -1.4978125
    tolerancia = 0.05
    tiempo_total = 600  # segundos
    puntuacion = 0
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)

        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo, (0, 0))

        # Científico
        screen.blit(cientifico, (70, 200))

        # Puerta (depende del resultado)
        if mostrar_resultado and exito:
            screen.blit(puerta_abierta, (600, 300))
        else:
            screen.blit(puerta_cerrada, (600, 300))


        # Enunciado
        dibujar_texto_en_caja("Nivel 1 - Método de Lagrange", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion}", font_text, BLACK, 600, 30)
        dibujar_texto_en_caja("Tu respuesta: " + input_text, font_text, BLACK, 50, 395)
        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Para abrir la puerta necesito saber el código el cual se obtiene",
            "de calcular g(x) para x = 6.4",
            "xi = 7.3, 6.5, 6.1",
            "yi = -0.28, -1.35, -1.96",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)


        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                msg = "¡Correcto! Avanzas al siguiente nivel."
                msg_render = font_text.render(msg, True, (0, 150, 0))
                screen.blit(msg_render, (50, 300))
                next_render = font_text.render("Presiona ENTER para continuar.", True, BLACK)
                screen.blit(next_render, (50, 340))
            else:
                if razon_error == "tiempo":
                    msg = "Se agotó el tiempo. Presiona ESC para volverlo a intentar."
                elif razon_error == "incorrecto":
                    msg = "Respuesta incorrecta. Presiona ESC para volverlo a intentar."
                else:
                    msg = "Presiona ESC para volverlo a intentar."

                msg_render = font_text.render(msg, True, (200, 0, 0))
                screen.blit(msg_render, (50, 300))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            respuesta = float(input_text)
                            if abs(respuesta - resultado_correcto) <= tolerancia and tiempo_restante > 0:
                                puntuacion = int(tiempo_restante * 10)
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        print("Avanzando al Nivel 2...")
                        running = False  # o nivel_2()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_1()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)

# ----------------- MENÚ PRINCIPAL -------------------
def draw_menu():
    screen.blit(fondo_menu, (0, 0))
    
    # Título
    title_text = font_title.render("Aventura Numérica", True, BLUE)
    screen.blit(title_text, (WIDTH//2 - title_text.get_width()//2, 100))

    # Botón Jugar
    pygame.draw.rect(screen, GRAY, play_button)
    play_text = font_button.render("Jugar", True, BLACK)
    screen.blit(play_text, (play_button.centerx - play_text.get_width()//2,
                            play_button.centery - play_text.get_height()//2))

    # Botón Salir
    pygame.draw.rect(screen, GRAY, exit_button)
    exit_text = font_button.render("Salir", True, BLACK)
    screen.blit(exit_text, (exit_button.centerx - exit_text.get_width()//2,
                             exit_button.centery - exit_text.get_height()//2))

    pygame.display.flip()

def main_menu():
    while True:
        draw_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(event.pos):
                    nivel_1()  # Iniciar nivel
                elif exit_button.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()

# Ejecutar el menú
main_menu()
