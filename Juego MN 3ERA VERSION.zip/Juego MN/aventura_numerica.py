import pygame
import math
import sys
import os

# Inicializar Pygame
pygame.init()

# Dimensiones de pantalla
WIDTH, HEIGHT = 800, 600
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Aventura Numérica")

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 100, 200)
GRAY = (200, 200, 200)

# Fuentes
font_title = pygame.font.SysFont(None, 80)
font_button = pygame.font.SysFont(None, 40)
font_text = pygame.font.SysFont(None, 32)

# Botones
play_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 50, 200, 60)
exit_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 30, 200, 60)

# Carga de imágenes
# Cargar frames del fondo animado del menú
def cargar_frames_menu(ruta_carpeta, tamaño):
    frames = []
    for nombre in sorted(os.listdir(ruta_carpeta)):
        if nombre.endswith(".png"):
            img = pygame.image.load(os.path.join(ruta_carpeta, nombre)).convert()
            img = pygame.transform.scale(img, tamaño)
            frames.append(img)
    return frames

# Carga los frames del menú animado
menu_frames = cargar_frames_menu("C:/Users/zahid/OneDrive/ESCRIT-1/JUEGO MN/menu", (WIDTH, HEIGHT))
frame_menu_actual = 0
contador_menu_frames = 0
retardo_menu_animacion = 5  # Ajusta velocidad de animación

# carga los frames de los niveles
def cargar_frames_desde_carpeta(ruta_carpeta):
    frames = []
    for nombre in sorted(os.listdir(ruta_carpeta)):
        if nombre.endswith((".png", ".jpg", ".gif")):
            imagen = pygame.image.load(os.path.join(ruta_carpeta, nombre)).convert_alpha()
            imagen = pygame.transform.scale(imagen, (100, 100))  # Asegúrate del tamaño
            frames.append(imagen)
    return frames

# Animaciones para éxito
cientifico_frames = cargar_frames_desde_carpeta("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/cientifico_moviendose")
puerta_frames = cargar_frames_desde_carpeta("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/puerta_abriendose")


#carga de imagenes de imagenes usadas
fondo = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/laboratorio.gif")
cientifico = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/cientifico.gif")
puerta_cerrada = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/puerta.gif")
puerta_abierta = pygame.image.load("C:/Users/zahid/OneDrive/ESCRIT-1/Juego MN/puerta.gif")

# Escalamos si es necesario
fondo = pygame.transform.scale(fondo, (SCREEN_WIDTH, SCREEN_HEIGHT))
cientifico = pygame.transform.scale(cientifico, (100, 100))
puerta_cerrada = pygame.transform.scale(puerta_cerrada, (100, 100))
puerta_abierta = pygame.transform.scale(puerta_abierta, (100, 100))

def dibujar_texto_en_caja(texto, fuente, color_texto, x, y, padding=10):
    render = fuente.render(texto, True, color_texto)
    ancho, alto = render.get_size()
    caja_rect = pygame.Rect(x - padding, y - padding, ancho + 2 * padding, alto + 2 * padding)
    pygame.draw.rect(screen, WHITE, caja_rect)         # Fondo blanco
    pygame.draw.rect(screen, BLACK, caja_rect, 2)      # Borde negro
    screen.blit(render, (x, y))

def dibujar_textos_en_caja_grande(lista_textos, fuente, color_texto, y, padding=10, espaciado=5):
    # Preparar los textos
    lineas_render = [fuente.render(texto, True, color_texto) for texto in lista_textos]
    alto_total = sum(r.get_height() + espaciado for r in lineas_render) - espaciado
    caja_altura = alto_total + 2 * padding
    caja_rect = pygame.Rect(0, y - padding, SCREEN_WIDTH, caja_altura)

    # Crear una superficie semitransparente
    fondo_caja = pygame.Surface((SCREEN_WIDTH, caja_altura), pygame.SRCALPHA)
    fondo_caja.fill((255, 255, 255, 180))  # Blanco con alfa (180 de 255)

    # Dibujar fondo y borde
    screen.blit(fondo_caja, (0, y - padding))
    pygame.draw.rect(screen, BLACK, caja_rect, 2)

    # Posicionar textos centrados
    y_actual = y
    for render in lineas_render:
        x = (SCREEN_WIDTH - render.get_width()) // 2
        screen.blit(render, (x, y_actual))
        y_actual += render.get_height() + espaciado
def dibujar_textos_en_caja_pie(lista_textos, fuente, color_texto, padding=10, espaciado=5):
    # Preparar los textos
    lineas_render = [fuente.render(texto, True, color_texto) for texto in lista_textos]
    alto_total = sum(r.get_height() + espaciado for r in lineas_render) - espaciado
    caja_altura = alto_total + 2 * padding
    y = SCREEN_HEIGHT - caja_altura  # Colocar al pie de la ventana

    caja_rect = pygame.Rect(0, y, SCREEN_WIDTH, caja_altura)

    # Crear superficie semitransparente
    fondo_caja = pygame.Surface((SCREEN_WIDTH, caja_altura), pygame.SRCALPHA)
    fondo_caja.fill((255, 255, 255, 180))  # Blanco con transparencia

    # Dibujar fondo y borde
    screen.blit(fondo_caja, (0, y))
    pygame.draw.rect(screen, BLACK, caja_rect, 2)

    # Dibujar texto alineado a la izquierda
    y_actual = y + padding
    for render in lineas_render:
        screen.blit(render, (padding, y_actual))
        y_actual += render.get_height() + espaciado

def mostrar_mensaje_centrado_doble_linea(texto1, texto2, fuente, color1, color2):
    render1 = fuente.render(texto1, True, color1)
    render2 = fuente.render(texto2, True, color2)

    ancho_caja = max(render1.get_width(), render2.get_width()) + 40
    alto_caja = render1.get_height() + render2.get_height() + 40
    x_caja = (WIDTH - ancho_caja) // 2
    y_caja = (HEIGHT - alto_caja) // 2

    fondo = pygame.Surface((ancho_caja, alto_caja))
    fondo.fill(WHITE)
    pygame.draw.rect(fondo, BLACK, fondo.get_rect(), 2)

    fondo.blit(render1, ((ancho_caja - render1.get_width()) // 2, 10))
    fondo.blit(render2, ((ancho_caja - render2.get_width()) // 2, 20 + render1.get_height()))

    screen.blit(fondo, (x_caja, y_caja))



# ----------------- NIVEL 1 -------------------
def nivel_1():
    frame_cientifico = 0
    frame_puerta = 0
    contador_animacion = 0
    running = True
    input_text = ""
    resultado_correcto = 10
    tolerancia = 0.05
    tiempo_total = 600  # segundos
    puntuacion = 0
    mostrar_resultado = False
    exito = False
    razon_error= ""

    clock = pygame.time.Clock()
    tiempo_inicio = pygame.time.get_ticks()  # Tiempo en milisegundos

    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_restante = max(0, tiempo_total - (tiempo_actual - tiempo_inicio) // 1000)

        screen.fill(WHITE)
        
        # Fondo
        screen.blit(fondo, (0, 0))

        # Científico y Puerta
        if mostrar_resultado and exito:
            # Animación
            contador_animacion += 1
            if contador_animacion % 5 == 0:  # Cambiar de frame cada 5 ticks (~12 FPS)
                frame_cientifico = (frame_cientifico + 1) % len(cientifico_frames)
                frame_puerta = (frame_puerta + 1) % len(puerta_frames)

            screen.blit(cientifico_frames[frame_cientifico], (70, 200))
            screen.blit(puerta_frames[frame_puerta], (600, 300))
        else:
            screen.blit(cientifico, (70, 200))
            screen.blit(puerta_cerrada, (600, 300))



        # Enunciado
        dibujar_texto_en_caja("Nivel 1 - Método de Lagrange", font_text, BLACK, 50, 30)
        dibujar_texto_en_caja(f"Puntuación: {puntuacion}", font_text, BLACK, 600, 30)
        dibujar_texto_en_caja("Tu respuesta: " + input_text, font_text, BLACK, 50, 395)
        textos = [
            f"Tiempo restante: {tiempo_restante}s",
            "Para abrir la puerta necesito saber el código el cual se obtiene",
            "de calcular g(x) para x = 6.4",
            "xi = 7.3, 6.5, 6.1",
            "yi = -0.28, -1.35, -1.96",
        ]
        dibujar_textos_en_caja_pie(textos, font_text, BLACK)


        # Mensaje de resultado
        if mostrar_resultado:
            if exito:
                mostrar_mensaje_centrado_doble_linea(
                    "¡Correcto! Avanzas al siguiente nivel.",
                    "Presiona ENTER para continuar.",
                    font_text,
                    (0, 150, 0),  # Verde para texto1
                    (0, 150, 0)   # Verde también para la instrucción
                )
            else:
                if razon_error == "tiempo":
                    texto_principal = "Se agotó el tiempo."
                elif razon_error == "incorrecto":
                    texto_principal = "Respuesta incorrecta."
                else:
                    texto_principal = "Intenta de nuevo."

                mostrar_mensaje_centrado_doble_linea(
                    texto_principal,
                    "Presiona ESC para volverlo a intentar.",
                    font_text,
                    (200, 0, 0),  # Rojo para texto1
                    (200, 0, 0)   # Rojo también para la instrucción
                )


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if not mostrar_resultado:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            respuesta = float(input_text)
                            if abs(respuesta - resultado_correcto) <= tolerancia and tiempo_restante > 0:
                                puntuacion = int(tiempo_restante * 10)
                                exito = True
                            else:
                                exito = False
                                razon_error = "incorrecto"
                            mostrar_resultado = True
                        except:
                            exito = False
                            razon_error = "incorrecto"
                            mostrar_resultado = True
                        input_text = ""
                    else:
                        input_text += event.unicode
                else:
                    if event.key == pygame.K_RETURN and exito:
                        print("Avanzando al Nivel 2...")
                        running = False  # o nivel_2()
                    elif event.key == pygame.K_ESCAPE:
                        nivel_1()  # Reinicia el nivel
                        return

        # Si el tiempo se agota y aún no se ha evaluado
        if tiempo_restante == 0 and not mostrar_resultado:
            exito = False
            razon_error = "tiempo"
            mostrar_resultado = True

        pygame.display.flip()
        clock.tick(60)

# ----------------- MENÚ PRINCIPAL -------------------
def draw_menu():
    global frame_menu_actual, contador_menu_frames

    # Animar fondo del menú
    contador_menu_frames += 1
    if contador_menu_frames >= retardo_menu_animacion:
        frame_menu_actual = (frame_menu_actual + 1) % len(menu_frames)
        contador_menu_frames = 0

    screen.blit(menu_frames[frame_menu_actual], (0, 0))


    # Título con borde blanco
    title_text = font_title.render("Aventura Numérica", True, BLUE)
    outline = font_title.render("Aventura Numérica", True, WHITE)
    x = WIDTH // 2 - title_text.get_width() // 2
    y = 100
    screen.blit(outline, (x - 2, y))
    screen.blit(outline, (x + 2, y))
    screen.blit(outline, (x, y - 2))
    screen.blit(outline, (x, y + 2))
    screen.blit(title_text, (x, y))

    # Obtener posición del mouse
    mouse_pos = pygame.mouse.get_pos()

    # Colores de botones
    play_color = (170, 170, 170) if play_button.collidepoint(mouse_pos) else GRAY
    exit_color = (170, 170, 170) if exit_button.collidepoint(mouse_pos) else GRAY

    # Botón Jugar
    pygame.draw.rect(screen, play_color, play_button)
    play_text = font_button.render("Jugar", True, BLACK)
    screen.blit(play_text, (play_button.centerx - play_text.get_width() // 2,
                            play_button.centery - play_text.get_height() // 2))

    # Botón Salir
    pygame.draw.rect(screen, exit_color, exit_button)
    exit_text = font_button.render("Salir", True, BLACK)
    screen.blit(exit_text, (exit_button.centerx - exit_text.get_width() // 2,
                             exit_button.centery - exit_text.get_height() // 2))

    pygame.display.flip()


def main_menu():
    while True:
        draw_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(event.pos):
                    nivel_1()  # Iniciar nivel
                elif exit_button.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()

# Ejecutar el menú
main_menu()
